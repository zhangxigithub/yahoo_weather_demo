yahoo_weather_demo
==================

模仿雅虎天气demo 只是简单搭了一个框架 交互细节都没有实现。

自娱自乐的东西，代码比较乱。


[演示视频](http://zhangxi.me)

